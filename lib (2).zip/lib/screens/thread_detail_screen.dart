import 'package:flutter/material.dart';

import '../models/thread_post.dart';
import '../viewmodels/thread_detail_view_model.dart';
import '../widgets/thread_card.dart';

class ThreadDetailScreen extends StatefulWidget {
  final ThreadPost thread;
  final bool isOwnPost;
  final bool isFollowed;
  final VoidCallback onToggleFollow;

  const ThreadDetailScreen({
    super.key,
    required this.thread,
    required this.isOwnPost,
    required this.isFollowed,
    required this.onToggleFollow,
  });

  @override
  State<ThreadDetailScreen> createState() => _ThreadDetailScreenState();
}

class _ThreadDetailScreenState extends State<ThreadDetailScreen> {
  late final ThreadDetailViewModel _viewModel = ThreadDetailViewModel(
    isFollowed: widget.isFollowed,
    onToggleFollow: widget.onToggleFollow,
  );

  @override
  void dispose() {
    _viewModel.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _viewModel,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Detail Postingan')),
        body: SafeArea(
          child: SingleChildScrollView(
            child: ThreadCard(
              thread: widget.thread,
              isOwnPost: widget.isOwnPost,
              isFollowed: _viewModel.isFollowed,
              onToggleFollow: _viewModel.toggleFollow,
              isDetail: true,
            ),
          ),
        ),
      ),
    );
  }
}
