import 'package:flutter/material.dart';

import '../models/thread_post.dart';
import '../models/user_profile.dart';
import '../routes/app_routes.dart';
import '../viewmodels/home_view_model.dart';
import 'thread_detail_screen.dart';
import '../theme/app_theme.dart';
import '../widgets/app_bottom_nav.dart';
import '../widgets/app_snackbar.dart';
import '../widgets/state_views.dart';
import '../widgets/thread_card.dart';

class HomeScreen extends StatefulWidget {
  // Data pengguna yang sedang login
  final UserProfile currentUser;
  const HomeScreen({super.key, required this.currentUser});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final HomeViewModel _viewModel = HomeViewModel();
  final _searchController = TextEditingController();
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _viewModel.loadThreads();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    _viewModel.dispose();
    super.dispose();
  }

  Future<void> _openCreateForm() async {
    final newThread = await Navigator.pushNamed<ThreadPost>(
      context,
      AppRoutes.createThread,
      arguments: widget.currentUser,
    );

    if (!mounted || newThread == null) return;

    _viewModel.onThreadCreated();
    _searchController.clear();

    // Gulir ke atas agar utas baru langsung terlihat
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) _scrollController.jumpTo(0);
    });

    AppSnackbar.showSuccess(context, 'Postingan berhasil dibuat!');
  }

  void _openThreadDetails(ThreadPost thread) {
    final isOwnPost = thread.authorName == widget.currentUser.name;
    Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (_) => ThreadDetailScreen(
          thread: thread,
          isOwnPost: isOwnPost,
          isFollowed: _viewModel.followed.contains(thread.authorName),
          onToggleFollow: () => _viewModel.toggleFollow(thread.authorName),
        ),
      ),
    );
  }

  void _onNavTap(int index) {
    if (index == 0) return; // sudah di Beranda
    _showSoon('Halaman ini belum tersedia.');
  }

  void _showSoon(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 2)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _viewModel,
      builder: (context, _) => Scaffold(
        body: SafeArea(
          bottom: false,
          child: Column(
            children: [
              _buildHeader(),
              _buildSearch(),
              _buildTabs(),
              _buildFilterChips(),
              Expanded(child: _buildContent()),
            ],
          ),
        ),
        bottomNavigationBar: AppBottomNav(
          currentIndex: 0,
          unreadCount: 3,
          onTap: _onNavTap,
          onCreate: _openCreateForm,
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.avatarBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.school_outlined, color: AppColors.primary),
          ),
          const SizedBox(width: 10),
          const Text(
            'UnandSpace',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: AppColors.primary,
            ),
          ),
          const Spacer(),
          // Avatar juga membuka menu simulasi error (khusus untuk demo)
          PopupMenuButton<String>(
            onSelected: (_) => _viewModel.toggleSimulateError(),
            itemBuilder: (context) => [
              CheckedPopupMenuItem(
                value: 'error',
                checked: _viewModel.simulateError,
                child: const Text('Simulasikan error kirim'),
              ),
            ],
            child: CircleAvatar(
              radius: 18,
              backgroundColor: AppColors.avatarBg,
              child: Text(
                widget.currentUser.initials,
                style: const TextStyle(
                  color: AppColors.primary,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearch() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchController,
              style: const TextStyle(fontSize: 13),
              onChanged: _viewModel.setQuery,
              decoration: InputDecoration(
                hintText: 'Cari topik, mata kuliah, komunitas...',
                hintStyle: const TextStyle(fontSize: 13),
                prefixIcon: const Icon(
                  Icons.search,
                  color: AppColors.primary,
                  size: 20,
                ),
                filled: true,
                fillColor: AppColors.chipBg,
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          IconButton.outlined(
            tooltip: 'Filter',
            onPressed: () => _showSoon('Filter lanjutan belum tersedia.'),
            icon: const Icon(Icons.tune, size: 18),
            style: IconButton.styleFrom(
              backgroundColor: AppColors.chipBg,
              foregroundColor: AppColors.textDark,
              side: const BorderSide(color: AppColors.border),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabs() {
    Widget tab(int index, String label) {
      final selected = _viewModel.tabIndex == index;
      return Expanded(
        child: InkWell(
          onTap: () => _viewModel.selectTab(index),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: selected ? AppColors.primary : Colors.transparent,
                  width: 2,
                ),
              ),
            ),
            child: Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: selected ? AppColors.primary : AppColors.textMuted,
              ),
            ),
          ),
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(children: [tab(0, 'Untuk Anda'), tab(1, 'Diikuti')]),
    );
  }

  Widget _buildFilterChips() {
    const labels = {
      FeedFilter.terbaru: 'Terbaru',
      FeedFilter.semuaKomunitas: 'Semua Komunitas',
      FeedFilter.terpopuler: 'Terpopuler',
      FeedFilter.belumTerjawab: 'Belum Terjawab',
    };
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        itemCount: labels.length,
        separatorBuilder: (context, index) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final filter = FeedFilter.values[index];
          final selected = _viewModel.filter == filter;
          return ChoiceChip(
            label: Text(labels[filter]!),
            selected: selected,
            showCheckmark: false,
            selectedColor: AppColors.primary,
            backgroundColor: Colors.white,
            side: BorderSide(
              color: selected ? AppColors.primary : AppColors.border,
            ),
            shape: const StadiumBorder(),
            labelStyle: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: selected ? Colors.white : AppColors.textMuted,
            ),
            onSelected: (_) => _viewModel.selectFilter(filter),
          );
        },
      ),
    );
  }

  Widget _buildContent() {
    return switch (_viewModel.status) {
      ViewStatus.loading => const LoadingView(message: 'Memuat utas...'),
      ViewStatus.error => ErrorView(
        message: _viewModel.errorMessage,
        onRetry: _viewModel.loadThreads,
      ),
      ViewStatus.success => _buildFeed(),
    };
  }

  Widget _buildFeed() {
    final threads = _viewModel.visibleThreads;
    if (threads.isEmpty) {
      return EmptyView(
        icon: Icons.forum_outlined,
        message: _viewModel.emptyMessage,
      );
    }
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.only(bottom: 16),
      itemCount: threads.length,
      itemBuilder: (context, index) {
        final t = threads[index];
        return ThreadCard(
          thread: t,
          isOwnPost: t.authorName == widget.currentUser.name,
          isFollowed: _viewModel.followed.contains(t.authorName),
          onToggleFollow: () => _viewModel.toggleFollow(t.authorName),
          onOpenDetails: () => _openThreadDetails(t),
        );
      },
    );
  }
}
