import 'package:flutter/foundation.dart';

class ThreadDetailViewModel extends ChangeNotifier {
  ThreadDetailViewModel({
    required this.isFollowed,
    required this.onToggleFollow,
  });

  bool isFollowed;
  final VoidCallback onToggleFollow;

  void toggleFollow() {
    isFollowed = !isFollowed;
    onToggleFollow();
    notifyListeners();
  }
}
