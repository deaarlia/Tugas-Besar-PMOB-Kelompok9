import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../data/thread_repository.dart';
import '../models/attachments.dart';
import '../models/thread_post.dart';
import '../models/user_profile.dart';
import '../utils/validators.dart';

class CreateThreadViewModel extends ChangeNotifier {
  CreateThreadViewModel({
    required this.author,
    ThreadRepository? repository,
    ImagePicker? imagePicker,
  }) : _repository = repository ?? ThreadRepository.instance,
       _imagePicker = imagePicker ?? ImagePicker() {
    titleController.addListener(_notifyListeners);
    contentController.addListener(_notifyListeners);
  }

  static const int maxTopics = 3;
  static const int maxContent = 1000;

  final UserProfile author;
  final ThreadRepository _repository;
  final ImagePicker _imagePicker;
  final TextEditingController titleController = TextEditingController();
  final TextEditingController contentController = TextEditingController();
  final List<String> _topics = [];
  final List<Uint8List> _photos = [];
  DocumentAttachment? _document;
  bool _isAnonymous = false;
  bool _isSubmitting = false;
  String? _errorMessage;
  bool _disposed = false;

  List<String> get topics => List.unmodifiable(_topics);
  List<Uint8List> get photos => List.unmodifiable(_photos);
  DocumentAttachment? get document => _document;
  bool get isAnonymous => _isAnonymous;
  bool get isSubmitting => _isSubmitting;
  String? get errorMessage => _errorMessage;
  bool get hasAttachments => _photos.isNotEmpty || _document != null;
  bool get hasUnsavedInput =>
      titleController.text.isNotEmpty ||
      contentController.text.isNotEmpty ||
      _topics.isNotEmpty ||
      hasAttachments;
  bool get canPost =>
      !_isSubmitting &&
      titleController.text.trim().length >= Validators.minTitleLength &&
      contentController.text.trim().length >= Validators.minContentLength;

  void setAnonymous(bool value) {
    _isAnonymous = value;
    _notifyListeners();
  }

  void removePhoto(int index) {
    _photos.removeAt(index);
    _notifyListeners();
  }

  void removeDocument() {
    _document = null;
    _notifyListeners();
  }

  void removeTopic(String topic) {
    _topics.remove(topic);
    _notifyListeners();
  }

  String? addTopic(String topic) {
    if (_topics.length >= maxTopics) return 'Maksimal $maxTopics topik.';
    _topics.add(topic);
    _notifyListeners();
    return null;
  }

  Future<ThreadPost?> submit() async {
    _isSubmitting = true;
    _errorMessage = null;
    _notifyListeners();

    try {
      final thread = await _repository.createThread(
        title: titleController.text.trim(),
        content: contentController.text.trim(),
        topics: _topics,
        photos: _photos,
        document: _document,
        author: author,
        isAnonymous: _isAnonymous,
      );
      return thread;
    } on ThreadException catch (e) {
      _setSubmissionError(e.message);
      return null;
    } catch (_) {
      _setSubmissionError('Terjadi kesalahan. Coba lagi nanti.');
      return null;
    }
  }

  Future<String?> attachPhoto() async {
    final countError = Validators.photoCount(_photos.length);
    if (countError != null) return countError;

    try {
      final file = await _imagePicker.pickImage(source: ImageSource.gallery);
      if (_disposed || file == null) return null;

      final sizeBytes = await file.length();
      if (_disposed) return null;
      final validationError = Validators.photoFile(
        file.name,
        sizeBytes,
        mimeType: file.mimeType,
      );
      if (validationError != null) return validationError;

      final bytes = await file.readAsBytes();
      if (_disposed) return null;
      final actualSizeError = Validators.photoFile(
        file.name,
        bytes.length,
        mimeType: file.mimeType,
      );
      if (actualSizeError != null) return actualSizeError;

      _photos.add(bytes);
      _notifyListeners();
      return null;
    } catch (_) {
      if (_disposed) return null;
      return 'Gagal membuka galeri. Coba lagi.';
    }
  }

  Future<String?> attachDocument() async {
    try {
      final file = await FilePicker.pickFile(
        type: FileType.custom,
        allowedExtensions: Validators.documentExtensions,
      );
      if (_disposed || file == null) return null;

      final sizeBytes = await file.length();
      if (_disposed) return null;
      if (sizeBytes == null) {
        return 'Ukuran dokumen tidak dapat dibaca. Coba berkas lain.';
      }

      final validationError = Validators.documentFile(file.name, sizeBytes);
      if (validationError != null) return validationError;

      final bytes = await file.readAsBytes();
      if (_disposed) return null;
      final actualSizeError = Validators.documentFile(file.name, bytes.length);
      if (actualSizeError != null) return actualSizeError;

      _document = DocumentAttachment(name: file.name, bytes: bytes);
      _notifyListeners();
      return null;
    } catch (e) {
      if (_disposed) return null;
      return 'Gagal memilih dokumen: $e';
    }
  }

  void _setSubmissionError(String message) {
    _errorMessage = message;
    _isSubmitting = false;
    _notifyListeners();
  }

  void _notifyListeners() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    titleController
      ..removeListener(_notifyListeners)
      ..dispose();
    contentController
      ..removeListener(_notifyListeners)
      ..dispose();
    super.dispose();
  }
}
