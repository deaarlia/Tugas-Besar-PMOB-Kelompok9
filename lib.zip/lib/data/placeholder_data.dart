import '../models/report_target.dart';

// PLACEHOLDER: isi diambil dari desain Figma supaya Beranda dan workflow
// laporan bisa didemokan. Hapus file ini saat utas sudah diambil dari
// REST API (pindahkan kelas DemoPost ke models/ lebih dulu).

class DemoPost {
  const DemoPost({
    required this.id,
    required this.author,
    required this.tag,
    required this.sub,
    required this.time,
    required this.title,
    required this.body,
    required this.votes,
    required this.comments,
    this.follow = true,
  });

  final String id, author, tag, sub, time, title, body;
  final int votes, comments;
  final bool follow;

  /// Data yang dikirim ke form laporan saat utas ini dilaporkan.
  ReportTarget toReportTarget() => ReportTarget(
        type: ReportTargetType.thread,
        id: id,
        authorName: author,
        excerpt: title,
        communityName: 'Forum $tag',
      );
}

const List<DemoPost> demoPosts = <DemoPost>[
  DemoPost(
    id: 'thread-1',
    author: 'Rafi Kurniawan',
    tag: 'FTI \'22',
    sub: 'Teknologi Informasi',
    time: '15 mnt lalu',
    title: 'Rekomendasi Dosen Pembimbing untuk Skripsi Machine Learning '
        'di Kampus Limau Manis?',
    body: 'Halo teman-teman FTI! Saya berencana mengambil topik Computer '
        'Vision untuk deteksi penyakit daun kelapa sawit di Sumbar. '
        'Kira-kira dosen pembimbing laboratorium mana yang paling cocok?',
    votes: 42,
    comments: 18,
  ),
  DemoPost(
    id: 'thread-2',
    author: 'Aisyah Putri',
    tag: 'FK \'21',
    sub: 'Kedokteran Umum',
    time: '3 jam lalu',
    title: 'Prosedur Pengajuan Cuti Akademik Semester Ganjil via Portal '
        'SIA Unand',
    body: 'Bagi yang perlu menunda semester karena magang MSIB atau alasan '
        'medis, berikut alur permohonan surat keterangan dekanat hingga '
        'persetujuan di sistem.',
    votes: 120,
    comments: 45,
  ),
];